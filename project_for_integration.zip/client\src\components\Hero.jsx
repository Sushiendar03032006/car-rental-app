import React, { useState } from 'react';
import { assets, cityList } from '../assets/assets';
import { useNavigate } from 'react-router-dom';

const Hero = () => {
  const [pickupLocation, setPickupLocation] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    // Only use pickupLocation in the search
    navigate(`/cars?pickupLocation=${pickupLocation}`);
  };

  return (
    <div className='h-screen flex flex-col items-center justify-center gap-14 bg-blue-50 text-center px-4'>
      {/* Heading */}
      <h1 className='text-4xl md:text-5xl font-semibold'>Luxury cars on Rent</h1>

      {/* Form */}
      <form
  onSubmit={handleSearch}
  className='flex flex-col md:flex-row items-center justify-between p-6 rounded-lg md:rounded-full w-full max-w-xs md:max-w-2xl bg-white shadow-[0px_8px_20px_rgba(0,0,0,0.1)] gap-4 md:gap-6'
>
  {/* Inputs */}
  <div className='flex flex-col md:flex-row items-start md:items-center gap-4 md:gap-6 flex-1'>
    {/* Pickup Location */}
    <div className='flex flex-col items-start gap-2'>
      <select
        required
        value={pickupLocation}
        onChange={(e) => setPickupLocation(e.target.value)}
        className='border border-gray-300 rounded px-2 py-1'
      >
        <option value=" "  disabled>Pickup Location</option>
        {cityList.map((city) => (
          <option key={city} value={city}>{city}</option>
        ))}
      </select>
      <p className='text-sm text-gray-500'>
        {pickupLocation ? pickupLocation : 'Please select location'}
      </p>
    </div>

    {/* Pickup Date */}
    <div className='flex flex-col items-start gap-2'>
      <label htmlFor='pickup-date' className='text-sm font-medium'>Pick-up Date</label>
      <input
        type='date'
        id='pickup-date'
        min={new Date().toISOString().split('T')[0]}
        required
        className='border border-gray-300 rounded px-2 py-1 text-sm text-gray-500'
      />
    </div>

    {/* Return Date */}
    <div className='flex flex-col items-start gap-2'>
      <label htmlFor='return-date' className='text-sm font-medium'>Return Date</label>
      <input
        type='date'
        id='return-date'
        min={new Date().toISOString().split('T')[0]}
        required
        className='border border-gray-300 rounded px-2 py-1 text-sm text-gray-500'
      />
    </div>
  </div>

  {/* Search Button */}
  <button
  type='submit'
  className='flex-shrink-0 flex items-center justify-center gap-2 px-6 py-2 mt-4 md:mt-0 bg-blue-500 hover:bg-blue-600 text-white rounded-full cursor-pointer'
>
  <img src={assets.search_icon} alt='search' className='w-5 h-5 brightness-300' />
  Search
</button>

 


  
</form>
 


      {/* Main Car Image */}
      <img src={assets.main_car} alt='car' className='max-h-72 w-auto mt-8' />
    </div>
  );
};

export default Hero;
