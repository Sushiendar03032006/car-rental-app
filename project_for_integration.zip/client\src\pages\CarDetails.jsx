import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { assets } from "../assets/assets";
import Loader from "../components/Loader";
import { useAppContext } from "../context/AppContext";
import { toast } from "react-hot-toast";

const CarDetails = () => {
  const FLASK_API_URL = "http://localhost:5000/predict_price";
  const { id } = useParams();

  const {
    cars,
    axios,
    pickupDate,
    setPickupDate,
    returnDate,
    setReturnDate,
  } = useAppContext();

  const navigate = useNavigate();
  const [car, setCar] = useState(null);

  // Form States
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [startLocation, setStartLocation] = useState("");
  const [endLocation, setEndLocation] = useState("");
  const [estimatedPrice, setEstimatedPrice] = useState(null);

  // ----------------------------------------------------------------
  // 📌 FIX: Robust Car Finding (Context -> Fallback to API)
  // ----------------------------------------------------------------
  useEffect(() => {
    const fetchCarData = async () => {
      // Strategy 1: Check if the car is already available in the global 'cars' Context
      // We convert IDs to strings to ensure "5" matches 5
      if (cars && cars.length > 0) {
        const foundCar = cars.find((c) => {
          const carId = c._id || c.id;
          return String(carId) === String(id);
        });

        if (foundCar) {
          setCar(foundCar);
          return; // Found in context, no need to fetch from API
        }
      }

      // Strategy 2: If not found in Context (e.g., Page Refresh), fetch directly from API
      try {
        // ⚠️ VERIFY THIS ROUTE: Ensure your backend has a route like router.get('/:id', ...)
        const { data } = await axios.get(`/api/cars/${id}`);

        if (data.success) {
          setCar(data.car);
        } else {
          toast.error("Car not found.");
          navigate("/"); // Redirect to home if invalid ID
        }
      } catch (error) {
        console.error("Error fetching single car:", error);
        // Only show error if we also failed to find it in context
        if (!car) toast.error("Could not load car details.");
      }
    };

    fetchCarData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, cars]); 

  // ----------------------------------------------------------------
  // 📌 Generate Price From Flask ML API
  // ----------------------------------------------------------------
  const handleGeneratePrice = async () => {
    if (!car) return;

    if (!pickupDate || !returnDate)
      return toast.error("Please select pickup and return dates first.");

    if (!startLocation || !endLocation)
      return toast.error("Please enter start & end locations.");

    try {
      const payload = {
        brand: car.brand,
        year: car.year,
        category: car.category,
        seatingCapacity: car.seating_capacity,
        fuelType: car.fuel_type,
        transmission: car.transmission,
        startLocation,
        dropLocation: endLocation,
        startDate: pickupDate,
        endDate: returnDate,
      };

      const response = await fetch(FLASK_API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const result = await response.json();

      if (result.error) return toast.error(result.error);

      setEstimatedPrice(result.predicted_price);
      toast.success("Price calculated successfully!");
    } catch (err) {
      console.error(err);
      toast.error("Prediction server error.");
    }
  };

  // ----------------------------------------------------------------
  // 📌 BOOK NOW
  // ----------------------------------------------------------------
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!estimatedPrice)
      return toast.error("Please generate price before booking.");

    try {
      const { data } = await axios.post("/api/bookings/create", {
        car: id,
        name,
        phone,
        pickupDate,
        returnDate,
        startLocation,
        endLocation,
        price: estimatedPrice,
      });

      if (data.success) {
        toast.success(data.message);

        // Reset Form
        setPickupDate("");
        setReturnDate("");
        setName("");
        setPhone("");
        setStartLocation("");
        setEndLocation("");
        setEstimatedPrice(null);

        navigate("/my-bookings");
      } else {
        toast.error(data.message);
      }
    } catch (error) {
      console.error(error);
      toast.error(error.response?.data?.message || error.message);
    }
  };

  // ----------------------------------------------------------------
  // UI RENDER
  // ----------------------------------------------------------------

  if (!car) return <Loader />;

  return (
    <div className="px-6 md:px-16 lg:px-24 xl:px-32 mt-16">
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-2 mb-6 text-gray-500 cursor-pointer"
      >
        <img src={assets.arrow_icon} alt="" className="rotate-180 opacity-65" />
        Back to all cars
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12">
        {/* LEFT SIDE: CAR INFO */}
        <div className="lg:col-span-2">
          <img
            src={car.image}
            alt={car.name || "Car"}
            className="w-full h-auto md:max-h-100 object-cover rounded-xl mb-6 shadow-md"
          />

          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold">
                {car.brand} {car.model}
              </h1>
              <p className="text-gray-500 text-lg">
                {car.category} • {car.year}
              </p>
            </div>

            <hr className="border-borderColor my-6" />

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="flex flex-col items-center bg-light p-4 rounded-lg">
                <img src={assets.users_icon} alt="" className="h-5 mb-2" />
                {car.seating_capacity} Seats
              </div>
              <div className="flex flex-col items-center bg-light p-4 rounded-lg">
                <img src={assets.fuel_icon} alt="" className="h-5 mb-2" />
                {car.fuel_type}
              </div>
              <div className="flex flex-col items-center bg-light p-4 rounded-lg">
                <img src={assets.car_icon} alt="" className="h-5 mb-2" />
                {car.transmission}
              </div>
              <div className="flex flex-col items-center bg-light p-4 rounded-lg">
                <img src={assets.location_icon} alt="" className="h-5 mb-2" />
                {car.location}
              </div>
            </div>

            <div>
              <h1 className="text-xl font-medium mb-3">Description</h1>
              <p className="text-gray-500">{car.description}</p>
            </div>
          </div>
        </div>

        {/* RIGHT SIDE: BOOKING FORM */}
        <form
          onSubmit={handleSubmit}
          className="shadow-lg h-max sticky top-18 rounded-xl p-6 space-y-6 text-gray-500"
        >
          <p className="flex items-center justify-between text-2xl text-gray-800 font-semibold">
            ₹{car.pricePerDay}
            <span className="text-base text-gray-400 font-normal">
              per day
            </span>
          </p>

          <hr className="border-borderColor my-6" />

          <div>
            <label>Full Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="border px-3 py-2 rounded-lg w-full"
              required
            />
          </div>

          <div>
            <label>Phone Number</label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="border px-3 py-2 rounded-lg w-full"
              required
            />
          </div>

          <div>
            <label>Start Location</label>
            <input
              type="text"
              value={startLocation}
              onChange={(e) => setStartLocation(e.target.value)}
              className="border px-3 py-2 rounded-lg w-full"
              required
            />
          </div>

          <div>
            <label>End Location</label>
            <input
              type="text"
              value={endLocation}
              onChange={(e) => setEndLocation(e.target.value)}
              className="border px-3 py-2 rounded-lg w-full"
              required
            />
          </div>

          <div>
            <label>Pickup Date</label>
            <input
              type="date"
              value={pickupDate}
              min={new Date().toISOString().split("T")[0]}
              onChange={(e) => setPickupDate(e.target.value)}
              className="border px-3 py-2 rounded-lg w-full"
              required
            />
          </div>

          <div>
            <label>Return Date</label>
            <input
              type="date"
              value={returnDate}
              min={pickupDate}
              onChange={(e) => setReturnDate(e.target.value)}
              className="border px-3 py-2 rounded-lg w-full"
              required
            />
          </div>

          <button
            type="button"
            onClick={handleGeneratePrice}
            className="w-full bg-gray-200 hover:bg-gray-300 py-2 rounded-lg transition-colors"
          >
            Generate Price
          </button>

          {estimatedPrice && (
            <div className="text-center bg-light border py-3 rounded-lg">
              <p className="font-medium">Estimated Price:</p>
              <p className="text-2xl font-bold text-gray-900">
                ₹{estimatedPrice}
              </p>
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-blue-500 hover:bg-blue-600 transition-colors py-3 rounded-xl font-medium text-white"
          >
            Book Now
          </button>
        </form>
      </div>
    </div>
  );
};

export default CarDetails;