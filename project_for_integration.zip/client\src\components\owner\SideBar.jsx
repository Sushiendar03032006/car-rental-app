import React, { useState } from 'react';
import { assets, ownerMenuLinks } from '../../assets/assets';
import { NavLink, useLocation } from 'react-router-dom';
import { useAppContext } from '../../context/AppContext';
import toast from 'react-hot-toast';

const Sidebar = () => {
  const { user, axios, fetchUser } = useAppContext();
  const location = useLocation();
  const [image, setImage] = useState('');

  const updateImage = async () => {
    try {
      const formData = new FormData();
      formData.append('image', image);
      const { data } = await axios.post('/api/owner/update-image', formData);

      if (data.success) {
        fetchUser();
        toast.success(data.message);
        setImage('');
      } else {
        toast.error(data.message);
      }
    } catch (error) {
      toast.error(error.message);
    }
  };

  return (
    <div className="relative min-h-screen md:flex flex-col items-center pt-10 max-w-16 md:max-w-60 w-full border-r border-gray-200 bg-white shadow-sm text-sm">
      {/* Profile Section */}
      <div className="group relative flex flex-col items-center">
        <label htmlFor="image" className="cursor-pointer relative">
          <img
            src={
              image
                ? URL.createObjectURL(image)
                : user?.image ||
                  'https://images.unsplash.com/photo-1633332755192-727a05c4013d?q=80&w=300'
            }
            alt="Profile"
            className="h-14 w-14 md:h-20 md:w-20 rounded-full object-cover border-2 border-gray-200 shadow-sm hover:shadow-md transition-all duration-200"
          />
          <input
            type="file"
            id="image"
            accept="image/*"
            hidden
            onChange={(e) => setImage(e.target.files[0])}
          />

          {/* Hover Edit Icon Overlay */}
          <div className="absolute inset-0 hidden group-hover:flex items-center justify-center bg-black/30 rounded-full">
            <img src={assets.edit_icon} alt="Edit" className="w-4 h-4 brightness-200" />
          </div>
        </label>

        {image && (
          <button
            onClick={updateImage}
            className="mt-2 flex items-center gap-1 px-3 py-1 bg-blue-50 text-blue-600 text-xs font-medium rounded-full hover:bg-blue-100 transition-all"
          >
            Save
            <img src={assets.check_icon} width={13} alt="Check" />
          </button>
        )}

        <p className="mt-3 text-base font-medium text-gray-700 max-md:hidden">
          {user?.name}
        </p>
      </div>

      {/* Menu Links */}
      <div className="w-full mt-8">
        {ownerMenuLinks.map((link, index) => {
          const active = link.path === location.pathname;
          return (
            <NavLink
              key={index}
              to={link.path}
              className={`relative flex items-center gap-3 w-full py-3 pl-5 pr-3 rounded-l-md transition-all duration-200 
                ${
                  active
                    ? 'bg-blue-50 text-blue-600 font-medium border-l-4 border-blue-500'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
            >
              <img
                src={active ? link.coloredIcon : link.icon}
                alt="icon"
                className="w-5 h-5"
              />
              <span className="max-md:hidden">{link.name}</span>
            </NavLink>
          );
        })}
      </div>
    </div>
  );
};

export default Sidebar;
