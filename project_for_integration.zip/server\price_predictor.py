# backend_app.py
# -------------------------------------------------
# Flask backend for dynamic car booking price prediction
# -------------------------------------------------

from flask import Flask, request, jsonify
from datetime import datetime
import pandas as pd
import numpy as np
import joblib, os
import googlemaps
from dotenv import load_dotenv
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor

from flask_cors import CORS  # <-- 1. IMPORT THIS

# --- Step 0: Load API Key ---
load_dotenv()
API_KEY = os.getenv("GOOGLE_MAPS_API_KEY")
if not API_KEY:
    print("Warning: GOOGLE_MAPS_API_KEY not found. Using fallback distance.", flush=True)
    gmaps = None
else:
    gmaps = googlemaps.Client(key=API_KEY)
    print("Google Maps client initialized.", flush=True)

MODEL_PATH = "car_booking_model.pkl"

# -------------------------------------------------
# Step 1: Helper function to get real distance
# -------------------------------------------------
def get_distance_km(start_location, drop_location):
    if start_location.lower() == drop_location.lower():
        return 0.0

    if gmaps is None:
        print("⚠ Using fallback distance 100 km.", flush=True)
        return 100.0

    try:
        directions = gmaps.directions(start_location, drop_location, mode="driving")
        if not directions:
            print("⚠ No directions result. Using default 100 km.", flush=True)
            return 100.0

        distance_meters = directions[0]['legs'][0]['distance']['value']
        return round(distance_meters / 1000, 2)

    except Exception as e:
        print(f"⚠ Google Maps API error: {e}. Using default 100 km.", flush=True)
        return 100.0


# -------------------------------------------------
# Step 2: Synthetic Training Data
# -------------------------------------------------
def build_training_data():
    np.random.seed(42)
    brands = ["Tata", "Toyota", "Ford", "Honda", "Hyundai", "Jeep"]
    categories = ["SUV", "Sedan", "Hatchback", "Van"]
    fuel_types = ["Petrol", "Diesel", "Hybrid", "Electric"]
    transmissions = ["Manual", "Automatic", "Semi-Automatic"]
    demand_factors = ["low", "medium", "high"]

    rows = []
    for _ in range(500):
        brand = np.random.choice(brands)
        category = np.random.choice(categories)
        fuel = np.random.choice(fuel_types)
        transmission = np.random.choice(transmissions)
        demand = np.random.choice(demand_factors, p=[0.3, 0.5, 0.2])
        year = np.random.randint(2018, 2024)
        seating = np.random.choice([2, 4, 5, 7])

        base_daily_rate = np.random.randint(200, 700)
        rental_days = np.random.randint(1, 14)
        is_one_way = np.random.choice([0, 1], p=[0.7, 0.3])
        drop_km = 0 if is_one_way == 0 else np.random.randint(50, 400)
        per_km_fee = np.random.uniform(8, 15)

        age_factor = 1 - (2025 - year) * 0.02
        demand_mult = {"low": 0.9, "medium": 1.0, "high": 1.2}[demand]
        fuel_mult = {"Diesel": 1.0, "Petrol": 0.95, "Hybrid": 1.1, "Electric": 1.25}[fuel]
        cat_mult = {"SUV": 1.2, "Sedan": 1.0, "Hatchback": 0.9, "Van": 0.85}[category]
        trans_mult = {"Automatic": 1.1, "Manual": 0.95, "Semi-Automatic": 1.05}[transmission]
        seat_mult = 1 + (seating - 4) * 0.05

        final_rate = base_daily_rate * age_factor * demand_mult * fuel_mult * cat_mult * trans_mult * seat_mult
        rental_cost = final_rate * rental_days
        drop_cost = drop_km * per_km_fee
        price = rental_cost + drop_cost
        final_price = round(price * np.random.normal(1.0, 0.05), 2)

        rows.append({
            "brand": brand,
            "year": year,
            "category": category,
            "seating_capacity": seating,
            "fuel_type": fuel,
            "transmission": transmission,
            "demand_factor": demand,
            "rental_duration_days": rental_days,
            "drop_off_distance_km": drop_km,
            "target_price": final_price
        })

    return pd.DataFrame(rows)


# -------------------------------------------------
# Step 3: Train Model
# -------------------------------------------------
def train_model():
    df = build_training_data()
    X = df.drop(columns=["target_price"])
    y = df["target_price"]

    cat_cols = ["brand", "category", "fuel_type", "transmission", "demand_factor"]
    num_cols = ["year", "seating_capacity", "rental_duration_days", "drop_off_distance_km"]

    preprocessor = ColumnTransformer(
        [
            ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
            ("num", "passthrough", num_cols)
        ]
    )

    model = Pipeline([
        ("pre", preprocessor),
        ("rf", RandomForestRegressor(n_estimators=150, random_state=42))
    ])

    model.fit(X, y)
    joblib.dump(model, MODEL_PATH)
    print(f"✅ Model trained & saved to {MODEL_PATH}")
    return model


# -------------------------------------------------
# Step 4: Load / Train
# -------------------------------------------------
if os.path.exists(MODEL_PATH):
    pipe = joblib.load(MODEL_PATH)
    print("✅ Loaded existing model.", flush=True)
else:
    pipe = train_model()


# -------------------------------------------------
# Step 5: Predict Function
# -------------------------------------------------
def predict_booking_price(data):
    # Parse dates
    start_date = datetime.strptime(data["start_date"], "%Y-%m-%d")
    end_date = datetime.strptime(data["end_date"], "%Y-%m-%d")

    # *** FIX: Allow same-day booking (count as 1 day) ***
    duration = (end_date - start_date).days
    
    if duration < 0:
        raise ValueError("End date cannot be before start date.")

    # If duration is 0 (same day), set to 1 day.
    # Otherwise, use the calculated duration (e.g., 1 day for 17th-18th).
    rental_duration_days = max(1, duration)

    data["rental_duration_days"] = rental_duration_days
    # *** END FIX ***

    # Distance
    distance = get_distance_km(data["start_location"], data["return_location"])
    data["drop_off_distance_km"] = distance

    # Prepare ML input
    features = [
        "brand", "year", "category", "seating_capacity",
        "fuel_type", "transmission", "demand_factor",
        "rental_duration_days", "drop_off_distance_km"
    ]

    df = pd.DataFrame([{key: data[key] for key in features}])
    price = pipe.predict(df)[0]

    return {
        "predicted_price": round(price, 2),
        "total_km": distance
    }


# -------------------------------------------------
# Step 6: Flask API
# -------------------------------------------------

# *** FIX: Define 'app' BEFORE using it ***
app = Flask(__name__)

# Now apply CORS to the 'app' variable
CORS(app, resources={r"/predict_price": {"origins": "http://localhost:5173"}})


@app.route("/", methods=["GET"])
def home():
    return {"message": "Car Booking Price Prediction API running"}


@app.route("/predict_price", methods=["POST"])
def predict_price():
    incoming = request.json

    # ---------------------------------------------
    # FIXED: Convert React camelCase → Python snake_case
    # ---------------------------------------------
    data = {
        "brand": incoming.get("brand"),
        "year": incoming.get("year"),
        "category": incoming.get("category"),
        "seating_capacity": incoming.get("seatingCapacity"),
        "fuel_type": incoming.get("fuelType"),
        "transmission": incoming.get("transmission"),

        "start_location": incoming.get("startLocation"),
        "return_location": incoming.get("dropLocation"),

        "start_date": incoming.get("startDate"),
        "end_date": incoming.get("endDate"),

        "demand_factor": incoming.get("demandFactor", "medium")
    }

    try:
        return predict_booking_price(data)
    except Exception as e:
        return {"error": str(e)}, 400


# -------------------------------------------------
if __name__ == "__main__":
    print("🚀 Starting Flask backend...", flush=True)
    app.run(debug=True, port=5000, use_reloader=False)