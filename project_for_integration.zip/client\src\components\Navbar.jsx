import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { assets, menuLinks } from "../assets/assets";
import car_rental_app_logo from "../assets/car-rental-app-logo.png";
import { useAppContext } from "../context/AppContext";

const Navbar = () => {
   const {setShowLogin, user, logout, isOwner, axios, setIsOwner} = useAppContext();

  const location = useLocation();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const changeRole= async ()=>{
    try {
      const {data}=await axios.post('/api/owner/change-role');
       if (data.success) {
                setIsOwner(true)
                toast.success(data.message)
            }else{
                toast.error(data.message)
            }
      
    } catch (error) {
        toast.error(error.message)
      
    }

  }

  return (
    <header
      className={`top-0 z-50 flex items-center justify-between w-full 
      px-6 md:px-16 lg:px-24 xl:px-32 py-4 
      border-b border-gray-200 shadow-sm
      ${location.pathname === "/" ? "bg-white" : "bg-white-500"}
      transition-all duration-300`}
    >
      {/* --- Brand / Logo --- */}
      <Link to="/" className="flex items-center gap-2">
        <img src={car_rental_app_logo} alt="DriveNow Logo" className="h-8 w-auto" />
        <span className="text-xl font-semibold text-gray-800">DriveNow</span>
      </Link>

      {/* --- Menu Links --- */}
      <nav
        className={`max-sm:fixed max-sm:h-screen max-sm:w-full max-sm:top-16 
        max-sm:right-0 flex flex-col sm:flex-row items-start sm:items-center 
        gap-6 sm:gap-8 max-sm:p-6 text-gray-700 font-medium
        bg-white max-sm:shadow-lg transition-transform duration-300 ease-in-out
        ${open ? "max-sm:translate-x-0" : "max-sm:translate-x-full"}`}
      >
        {menuLinks.map((link, index) => (
          <Link
            key={index}
            to={link.path}
            className="hover:text-blue-600 transition-colors"
            onClick={() => setOpen(false)}
          >
            {link.name}
          </Link>
        ))}

        {/* --- Search --- */}
        <div className="hidden lg:flex items-center text-sm gap-2 border border-gray-300 px-3 rounded-full max-w-56">
          <input
            type="text"
            className="py-1.5 w-full bg-transparent outline-none placeholder-gray-500"
            placeholder="Search cars..."
          />
          <img src={assets.search_icon} alt="search" className="h-5 w-5 opacity-70" />
        </div>

        {/* --- Buttons --- */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mt-4 sm:mt-0">
          <button
            onClick={()=> isOwner ? navigate('/owner') : changeRole()}
            className="text-gray-700 font-medium hover:text-blue-600 transition-colors"
          >
           {isOwner ? 'Dashboard' : 'List cars'}
          </button>

          <button
            onClick={()=> {user ? logout() : setShowLogin(true)}}
            className="px-6 py-2 rounded-lg text-white bg-blue-600 hover:bg-blue-700 transition-all duration-300 shadow-md"
          >
            {user ? "Logout":"Login"}
          </button>
        </div>
      </nav>

      {/* --- Mobile Menu Button --- */}
      <button
        className="sm:hidden cursor-pointer"
        aria-label="Menu"
        onClick={() => setOpen(!open)}
      >
        <img
          src={open ? assets.close_icon : assets.menu_icon}
          alt="menu"
          className="h-6 w-6"
        />
      </button>
    </header>
  );
};

export default Navbar;
