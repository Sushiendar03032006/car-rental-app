import React, { useState } from "react";

const Newsletter = () => {
  const [email, setEmail] = useState("");

  const handleSubscribe = (e) => {
    e.preventDefault(); // prevents page reload
    if (email) {
      alert(`Subscribed with ${email}!`);
      setEmail(""); // reset input
    }
  };

  return (
    <div className="flex flex-col items-center justify-center text-center space-y-4 max-w-3xl mx-auto my-10 px-4">
      <h1 className="md:text-4xl text-2xl font-semibold">
        Never Miss a Deal!
      </h1>
      <p className="md:text-lg text-gray-500/70 pb-6">
        Subscribe to get the latest offers, new arrivals, and exclusive discounts
      </p>

      <form
        onSubmit={handleSubscribe}
        className="flex w-full max-w-2xl h-12 md:h-14"
      >
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter your email id"
          required
          className="flex-1 border border-gray-300 rounded-l-md px-3 text-gray-700 outline-none"
        />
        <button
          type="submit"
          className="px-8 md:px-12 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-r-md transition-colors"
        >
          Subscribe
        </button>
      </form>
    </div>
  );
};

export default Newsletter;
