import React from 'react';
import { assets, dummyUserData } from '../../assets/assets';
import { Link } from 'react-router-dom';
import car_rental_app_logo from '../../assets/car-rental-app-logo.png'; // ✅ fixed path
import { useAppContext } from '../../context/AppContext';

const NavbarOwner = () => {
  const {user}=useAppContext();
  return (
    <div className='flex items-center justify-between px-6 md:px-10 py-4 text-gray-600 border-b border-borderColor bg-white shadow-sm'>
      {/* Left: Logo + Brand name */}
      <Link to='/' className='flex items-center gap-2'>
        <img src={car_rental_app_logo} alt="logo" className="h-8 w-auto" />
        <span className='text-lg font-semibold text-gray-800 tracking-wide'>
          DriveNow
        </span>
      </Link>

      {/* Right: Welcome message */}
      <p className='text-sm md:text-base text-gray-600'>
        Welcome, <span className='font-medium text-gray-800'>{user?.name || "Owner"}</span>
      </p>
    </div>
  );
};

export default NavbarOwner;
