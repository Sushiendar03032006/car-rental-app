# backend_app.py
from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import numpy as np
from datetime import datetime
import joblib, os
import googlemaps
from dotenv import load_dotenv

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor

load_dotenv()

API_KEY = os.getenv("GOOGLE_MAPS_API_KEY")
gmaps = googlemaps.Client(key=API_KEY) if API_KEY else None

MODEL_PATH = "car_booking_model.pkl"

# ---------------------------------------------------
# Distance
# ---------------------------------------------------
def get_distance_km(start_location, drop_location):
    if start_location.lower() == drop_location.lower():
        return 0.0

    if not gmaps:
        return 100.0

    try:
        results = gmaps.directions(start_location, drop_location, mode="driving")
        if not results:
            return 100.0
        return results[0]["legs"][0]["distance"]["value"] / 1000
    except:
        return 100.0

# ---------------------------------------------------
# Build synthetic dataset
# ---------------------------------------------------
def build_training_data():
    np.random.seed(42)
    brands = ["Tata", "Toyota", "Ford", "Honda", "Hyundai", "Jeep"]
    categories = ["SUV", "Sedan", "Hatchback", "Van"]
    fuel_types = ["Petrol", "Diesel", "Hybrid", "Electric"]
    transmissions = ["Manual", "Automatic", "Semi-Automatic"]
    demand = ["low", "medium", "high"]

    rows = []
    for _ in range(500):
        brand = np.random.choice(brands)
        category = np.random.choice(categories)
        fuel = np.random.choice(fuel_types)
        transmission = np.random.choice(transmissions)
        d = np.random.choice(demand, p=[0.3, 0.5, 0.2])
        year = np.random.randint(2018, 2024)
        seating = np.random.choice([2, 4, 5, 7])

        base_rate = np.random.randint(200, 700)
        days = np.random.randint(1, 14)
        is_one_way = np.random.choice([0, 1], p=[0.7, 0.3])
        drop_km = 0 if is_one_way == 0 else np.random.randint(50, 400)

        per_km = np.random.uniform(8, 15)
        price = base_rate * days + drop_km * per_km
        final_price = price * np.random.normal(1.0, 0.05)

        rows.append({
            "brand": brand,
            "year": year,
            "category": category,
            "seating_capacity": seating,
            "fuel_type": fuel,
            "transmission": transmission,
            "demand_factor": d,
            "rental_duration_days": days,
            "drop_off_distance_km": drop_km,
            "target_price": round(final_price, 2)
        })
    return pd.DataFrame(rows)

# ---------------------------------------------------
# Train model
# ---------------------------------------------------
def train_model():
    df = build_training_data()
    X = df.drop(columns=["target_price"])
    y = df["target_price"]

    cat_cols = ["brand", "category", "fuel_type", "transmission", "demand_factor"]
    num_cols = ["year", "seating_capacity", "rental_duration_days", "drop_off_distance_km"]

    pre = ColumnTransformer(
        [("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
         ("num", "passthrough", num_cols)]
    )

    model = Pipeline([
        ("pre", pre),
        ("rf", RandomForestRegressor(n_estimators=150, random_state=42))
    ])

    model.fit(X, y)
    joblib.dump(model, MODEL_PATH)
    return model

# ---------------------------------------------------
# Load model
# ---------------------------------------------------
if os.path.exists(MODEL_PATH):
    pipe = joblib.load(MODEL_PATH)
else:
    pipe = train_model()

# ---------------------------------------------------
# Predict
# ---------------------------------------------------
def predict_booking_price(data):
    start_date = datetime.strptime(data["start_date"], "%Y-%m-%d")
    end_date = datetime.strptime(data["end_date"], "%Y-%m-%d")

    days = (end_date - start_date).days
    data["rental_duration_days"] = days

    dist = get_distance_km(data["start_location"], data["return_location"])
    data["drop_off_distance_km"] = dist

    

    features = [
        "brand", "year", "category", "seating_capacity", "fuel_type",
        "transmission", "demand_factor", "rental_duration_days",
        "drop_off_distance_km"
    ]

    df = pd.DataFrame([{f: data[f] for f in features}])
    price = pipe.predict(df)[0]

    return {"predicted_price": round(price, 2), "total_km": dist}


# ---------------------------------------------------
# Flask App
# ---------------------------------------------------
app = Flask(__name__)
CORS(app, origins=["http://localhost:5173"])

@app.route("/predict_price", methods=["POST"])
def predict_price():
    incoming = request.json

    data = {
        "brand": incoming.get("brand"),
        "year": incoming.get("year"),
        "category": incoming.get("category"),
        "seating_capacity": incoming.get("seatingCapacity"),
        "fuel_type": incoming.get("fuelType"),
        "transmission": incoming.get("transmission"),

        "start_location": incoming.get("startLocation"),
        "return_location": incoming.get("dropLocation"),

        "start_date": incoming.get("startDate"),
        "end_date": incoming.get("endDate"),

        "demand_factor": incoming.get("demandFactor", "medium")
    }

    try:
        return predict_booking_price(data)
    except Exception as e:
        return {"error": str(e)}, 400


if __name__ == "__main__":
    app.run(debug=True, port=5000)
