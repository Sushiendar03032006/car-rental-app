import React, { useEffect, useState } from "react";
import { assets, dummyMyBookingsData } from "../assets/assets";
import Title from "../components/Title";

// Helper function to format ISO date to "DD MMM YYYY" (for rental period)
const formatDate = (isoDate) => {
  const options = { day: "2-digit", month: "short", year: "numeric" };
  return new Date(isoDate).toLocaleDateString(undefined, options);
};

// Helper function to format ISO date to "DD MMM YYYY, HH:MM" (for booked on)
const formatDateTime = (isoDate) => {
  const options = {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false, // 24-hour format
  };
  return new Date(isoDate).toLocaleString(undefined, options);
};

// Helper function to calculate number of rental days
const calculateDays = (startDate, endDate) => {
  const start = new Date(startDate);
  const end = new Date(endDate);
  const diffTime = end - start;
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) || 1; // minimum 1 day
  return diffDays;
};

const MyBookings = () => {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    setBookings(dummyMyBookingsData);
  }, []);

  return (
    <div className="px-6 md:px-16 lg:px-24 xl:px-32 2xl:px-48 mt-16 text-sm max-w-7xl">
      <Title
        title="My Bookings"
        subTitle="View and manage all your car bookings"
        align="left"
      />

      <div>
        {bookings.map((booking, index) => {
          const rentalDays = calculateDays(booking.pickupDate, booking.returnDate);
          const totalPrice = booking.car.pricePerDay * rentalDays;

          return (
            <div
              key={booking._id}
              className="grid grid-cols-1 md:grid-cols-4 gap-6 p-6 border border-borderColor rounded-lg mt-5 first:mt-12"
            >
              {/* Car Info */}
              <div className="md:col-span-1">
                <div className="rounded-md overflow-hidden mb-3">
                  <img
                    src={booking.car.image}
                    alt=""
                    className="w-full h-auto aspect-video object-cover"
                  />
                </div>
                <p className="text-lg font-medium mt-2">
                  {booking.car.brand} {booking.car.model}
                </p>
                <p className="text-gray-500">
                  {booking.car.year} • {booking.car.category} • {booking.car.location}
                </p>
              </div>

              {/* Booking Info */}
              <div className="md:col-span-2">
                <div className="flex items-center gap-2">
                  <p className="px-3 py-1.5 bg-light rounded">Booking #{index + 1}</p>
                  <p
                    className={`px-3 py-1 text-xs rounded-full ${
                      booking.status === "confirmed"
                        ? "bg-green-400/15 text-green-600"
                        : "bg-red-400/15 text-red-600"
                    }`}
                  >
                    {booking.status}
                  </p>
                </div>

                {/* Rental Period */}
                <div className="flex items-start gap-2 mt-3">
                  <img
                    src={assets.calendar_icon_colored}
                    alt=""
                    className="w-4 h-4 mt-1"
                  />
                  <div>
                    <p className="text-gray-500">Rental Period</p>
                    <p>
                      {formatDate(booking.pickupDate)} to {formatDate(booking.returnDate)}
                    </p>
                  </div>
                </div>

                {/* Start Location */}
                <div className="flex items-start gap-2 mt-3">
                  <img
                    src={assets.location_icon_colored}
                    alt=""
                    className="w-4 h-4 mt-1"
                  />
                  <div>
                    <p className="text-gray-500">Start Location</p>
                    <p>{booking.startLocation}</p>
                  </div>
                </div>

                {/* End Location */}
                <div className="flex items-start gap-2 mt-3">
                  <img
                    src={assets.location_icon_colored}
                    alt=""
                    className="w-4 h-4 mt-1"
                  />
                  <div>
                    <p className="text-gray-500">End Location</p>
                    <p>{booking.endLocation}</p>
                  </div>
                </div>

                {/* Customer Name */}
                <div className="flex items-start gap-2 mt-3">
                  <div>
                    <p className="text-gray-500">Customer Name</p>
                    <p>{booking.name}</p>
                  </div>
                </div>

                {/* Phone Number */}
                <div className="flex items-start gap-2 mt-3">
                  <div>
                    <p className="text-gray-500">Phone Number</p>
                    <p>{booking.phone}</p>
                  </div>
                </div>
              </div>

              {/* Price Section */}
              <div className="md:col-span-1 flex flex-col justify-between gap-6">
                <div className="text-sm text-gray-500 text-right">
                  <p>Total Price ({rentalDays} days)</p>
                  <h1 className="text-2xl font-semibold text-primary">₹{totalPrice}</h1>
                  <p>Booked on {formatDateTime(booking.createdAt)}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default MyBookings;
